#pragma once
#include <SFML/Graphics.hpp>
#include <vector>
#include <string>
#include "TruthTable.h"

// Draws a Karnaugh Map for 2, 3, or 4 variables.
// Gray code ordering per standard K-Map layout.
// Shows cell values (0/1) with color fill.
// Shows minterm numbers and Σm() notation.

class KMapDrawer {
public:
    void build(TruthTable& table, sf::Font& font,
               float px, float py, float pw, float ph);
    void draw(sf::RenderWindow& window);

    bool visible = false;

private:
    std::vector<sf::RectangleShape> cells;
    std::vector<sf::Text>           cellTexts;
    std::vector<sf::Vertex>         gridLines;
    std::vector<sf::Text>           headerTexts;
    sf::Text                        titleText;
    sf::Text                        mintermText;

    sf::Font* font = nullptr;

    // Gray code orders for rows/cols
    // 2-var: cols=AB: 00,01,11,10
    // 3-var: rows=A: 0,1  cols=BC: 00,01,11,10
    // 4-var: rows=AB: 00,01,11,10  cols=CD: 00,01,11,10

    void build2var(TruthTable& t, float px, float py, float pw, float ph);
    void build3var(TruthTable& t, float px, float py, float pw, float ph);
    void build4var(TruthTable& t, float px, float py, float pw, float ph);

    // Gray code sequence for n bits: 0→1→3→2 for 2 bits
    static std::vector<int> grayOrder(int bits);

    // Get output value for a given row index in truth table
    static int getOutput(TruthTable& t, int rowIndex);

    void buildMintermString(TruthTable& t, float x, float y);
};
