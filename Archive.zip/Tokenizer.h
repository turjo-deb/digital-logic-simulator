#pragma once
#include <string>
#include <vector>

// Tokenizer splits raw expression string into list of tokens.
// Example:  "(A & B) | !C"
// Becomes:  ["(", "A", "&", "B", ")", "|", "!", "C"]

class Tokenizer {
public:
    // Takes raw expression, returns list of token strings
    std::vector<std::string> tokenize(const std::string& expr);
};
