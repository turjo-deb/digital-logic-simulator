#pragma once
#include <SFML/Graphics.hpp>
#include <string>
#include <vector>
#include <map>
#include <memory>
#include "Tokenizer.h"
#include "Parser.h"
#include "TruthTable.h"
#include "CircuitDrawer.h"

class GUI {
public:
    GUI();
    void run();

private:
    sf::RenderWindow window;
    sf::Font font;

    sf::RectangleShape inputBox;
    sf::Text inputText;
    std::string inputString;
    bool inputFocused;

    sf::RectangleShape runButton;
    sf::Text runButtonText;

    sf::RectangleShape exportButton;
    sf::Text exportButtonText;

    sf::RectangleShape circuitPanel;
    sf::RectangleShape tablePanel;

    sf::Text titleText;
    sf::Text circuitLabel;
    sf::Text tableLabel;
    sf::Text statusText;

    Tokenizer  tokenizer;
    Parser     parser;
    TruthTable truthTable;
    CircuitDrawer circuitDrawer;
    std::shared_ptr<Node> root;
    bool hasResult;

    std::vector<sf::Text>            tableTexts;
    std::vector<sf::Vertex>          gridLines;
    std::vector<sf::RectangleShape>  rowHighlights;  // selected row bg

    // Row selection state
    int  selectedRow;   // -1 = none
    float rowH_cache;   // row height used during last buildTableTexts
    float tableStartY_cache;

    void handleEvents();
    void update();
    void draw();
    void setupUI();
    void onRunClicked();
    void rebuildCircuit();
    void buildTableTexts();
    void onTableClick(float mouseY);
    void onExportClicked();       // save truth table to .txt
};