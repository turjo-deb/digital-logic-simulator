#include "TruthTable.h"
#include <iostream>
#include <iomanip>  
#include <cmath>   

void TruthTable::generate(
    std::shared_ptr<Node> root,
    std::map<std::string, std::shared_ptr<InputNode>>& varMap
) {
    rows.clear();
    vars.clear();

    for (auto& [name, node] : varMap) {
        vars.push_back(name);
    }
    int n = vars.size();
    int totalRows = 1 << n; 
    for (int i = 0; i < totalRows; i++) {
        Row row;
        for (int j = 0; j < n; j++) {
            bool val = (i >> (n - 1 - j)) & 1;
            varMap[vars[j]]->value = val; 
            row.inputs[vars[j]] = val;
        }
        row.output = root->evaluate();
        rows.push_back(row);
    }
}

void TruthTable::print() {
    for (auto& v : vars) {
        printCell<std::string>(v);
    }
    std::cout << "  | OUT\n";
    int width = vars.size() * 4 + 8;
    std::cout << std::string(width, '-') << "\n";
    for (auto& row : rows) {
        for (auto& v : vars) {
            printCell<bool>(row.inputs.at(v));
        }
        std::cout << "  |  " << row.output << "\n";
    }
}