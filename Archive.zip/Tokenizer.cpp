#include "Tokenizer.h"

std::vector<std::string> Tokenizer::tokenize(const std::string& expr) {
    std::vector<std::string> tokens;

    for (int i = 0; i < (int)expr.size(); i++) {
        char c = expr[i];

        // Skip spaces
        if (c == ' ') continue;

        // Single-character operators and brackets → each is its own token
        if (c == '&' || c == '|' || c == '!' || c == '^' ||
            c == '(' || c == ')') {
            tokens.push_back(std::string(1, c));  // convert char to string
        }
        // Letters (A-Z, a-z) → variable name
        // We collect full name in case someone writes "AB" etc.
        else if (isalpha(c)) {
            std::string name = "";
            while (i < (int)expr.size() && isalpha(expr[i])) {
                name += expr[i];
                i++;
            }
            i--;  // step back one (loop will i++ again)
            tokens.push_back(name);
        }
        // Anything else → skip (could add error handling here later)
    }

    return tokens;
}
